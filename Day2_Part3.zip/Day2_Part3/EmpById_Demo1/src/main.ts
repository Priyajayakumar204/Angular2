import { Component,NgModule,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { FormsModule } from '@angular/forms';
enableProdMode();

@Component({
  selector: 'my-app',
  templateUrl: 'src/main.component.html',
})


export class GuestComponent implements OnInit{
   private emps:Employee[];
   emps= [  
	 { "id": 101, "name": "Ram","desig":"TL" },    
	 { "id": 104, "name": "Ravan","desig":"SSE" },    
	 { "id": 109, "name": "Lakshman","desig":"TL" },   
	 { "id": 121, "name": "Krish","desig":"TL" },    
	 { "id": 141, "name": "Lava","desig":"SE" },    
	 { "id": 155, "name": "Kucha","desig":"SE" },  
	 { "id": 167, "name": "Shiv","desig":"PM" }			 
  ];
  eid:number=0;
  show:boolean=false;
  e:Employee;
  getDetails()
  {
	this.show=true;
	for(let i=0;i<(this.emps).length;i++)
	{
	if((this.emps[i]).id==this.eid)
	this.e=this.emps[i];
	}
  }
}

@NgModule({
  imports:      [ BrowserModule, FormsModule ],
  declarations: [ GuestComponent ],
  bootstrap:    [ GuestComponent ]
})
export class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);

  