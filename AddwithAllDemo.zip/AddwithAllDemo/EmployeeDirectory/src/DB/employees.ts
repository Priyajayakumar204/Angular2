import {FormatName} from '../Models/FullName';
import {IEmployee} from '../Models/IEmployee';
export const employees:IEmployee[] = [{
    "empId": 1,
    "empName" : new FormatName("Preetham","Salehundam").fullName,
    "empDOJ": new Date() 
},
{
    "empId": 2,
    "empName" : new FormatName("Vishnu","Vardhan").fullName,
    "empDOJ": new Date() 
},
{
    "empId": 3,
    "empName" : new FormatName("Omnath","karthikeyan").fullName,
    "empDOJ": new Date() 
},{
    "empId": 4,
    "empName" : new FormatName("Rakesh","Vandavasi").fullName,
    "empDOJ": new Date() 
},{
    "empId": 5,
    "empName" : new FormatName("Himatej","").fullName,
    "empDOJ": new Date() 
},{
    "empId": 6,
    "empName" : new FormatName("Vineet","C").fullName,
    "empDOJ": new Date() 
},{
    "empId": 7,
    "empName" : new FormatName("Shubendhu","Dwivedi").fullName,
    "empDOJ": new Date() 
}];

