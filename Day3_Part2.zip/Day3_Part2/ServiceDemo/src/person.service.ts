import { Injectable } from '@angular/core';
import { IPerson } from './person';


@Injectable()
export class PersonService {
     getPersons():IPerson[]{
        return  [  
             { id: 1, name: 'Karthik' },    
             { id: 2, name: 'Anil' },    
             { id: 3, name: 'Ganesh' } 
           ]
    }
}