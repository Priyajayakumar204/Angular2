import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic'
import { RedDirective } from './custom.directive';

enableProdMode();

@Component({
  selector: 'my-app',
   template: `<h1 testRed> Let's 'RED' me!</h1>
   <h1> Let's See me!</h1>
   <p testRed> Paragraph here!</p>
   <h1 testRed> Let's c d footer</h1>
   `
})
export class DirectiveComponent {}

@NgModule({
	imports:[ BrowserModule ],
	declarations:[ DirectiveComponent,RedDirective ],
	bootstrap:[ DirectiveComponent ]
})
export class AppComponent{}

platformBrowserDynamic().bootstrapModule(AppComponent);