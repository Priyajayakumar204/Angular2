import {Component,Input,Output,EventEmitter} from '@angular/core';

@Component({
  selector: 'child-selector',
  template: `<h2>{{title}}</h2> `
  
})
export class ChildComponent {  
  title = 'I am a nested component';
}

