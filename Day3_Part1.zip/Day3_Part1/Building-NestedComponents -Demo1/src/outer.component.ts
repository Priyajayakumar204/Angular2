import { Component } from '@angular/core';
import { ChildComponent } from './inner.component';

@Component({
  selector: 'my-app',
  template: `<div>  
			  <h1>I'm a container component</h1>
			  <child-selector></child-selector>
			 </div> `
})
export class ParentComponent { }  