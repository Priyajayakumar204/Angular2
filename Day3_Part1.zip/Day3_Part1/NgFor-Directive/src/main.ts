import { Component,NgModule,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
enableProdMode();

@Component({
    selector:'my-app',
    template:`<div>
        <h1>Ng-For Directive</h1>
        <hr/>
        <ul>
            <li *ngFor="let city of cities">{{ city }}</li>
        </ul>
        <hr/>
		<br/>
		<h1>Choose a city</h1>
		<select>
		<option *ngFor="let temp of cities" value="{{temp}}">{{temp}}</option>
		</select>
        <br/>
		<select [(ngModel)]="cityChoice">
            <option *ngFor="let city of cities; let counter=index" [value]="counter">{{ city }}</option>
        </select>
		You have selected {{cityChoice}}
        <hr/>
         <select>
            <option *ngFor="let employee of employees" [value]="employee.id">{{ employee.id+"-"+employee.name }}</option>
        </select>
		<br/>
		<h1> Employee details</h1>
		<table>
		<tr> <td> Id</td><td> Name</td></tr>
		<tr *ngFor="let e1 of employees">
		  <td>{{e1.id}}</td>
		  <td>{{e1.name}}</td>
		</tr>
		</table>
     </div>`
})
class StructuralComponent{
   cities:string[] = ["Chennai","Bangalore","Mumbai"];
   employees:any = [
       {id:714709,name:"Karthik"},
       {id:707224,name:"Latha"},
       {id:714733,name:"Ganesh"}
    ];
	cityChoice:string;
}
@NgModule({
    imports:[ BrowserModule,FormsModule ],
    declarations:[ StructuralComponent ],
    bootstrap:[ StructuralComponent ]
})
class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);